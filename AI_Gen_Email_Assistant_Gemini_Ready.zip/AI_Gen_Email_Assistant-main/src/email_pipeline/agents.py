from __future__ import annotations

import json
from typing import List, Optional

from google import genai
from google.genai import types

from . import prompts
from .schemas import (
    ContextPack,
    EmailDraft,
    IntentClassification,
    ParsedInput,
    PersonalizedEmail,
    ReviewResult,
    RoutingDecision,
    ToneStyleSpec,
    UserEmailContext,
)


class AgentError(RuntimeError):
    pass


class GeminiResponseAgent:
    def __init__(self, client: genai.Client, model: str):
        self._client = client
        self._model = model

    def _parse(self, *, messages: list[dict], response_model: type, temperature: float) -> object:
        # Gemini structured output: ask for JSON that follows the Pydantic schema.
        system_prompt = messages[0]["content"] if messages and messages[0].get("role") == "system" else ""
        user_prompt = "\\n\\n".join(
            item.get("content", "") for item in messages if item.get("role") != "system"
        )
        try:
            response = self._client.models.generate_content(
                model=self._model,
                contents=user_prompt,
                config=types.GenerateContentConfig(
                    system_instruction=system_prompt,
                    response_mime_type="application/json",
                    response_schema=response_model,
                    temperature=temperature,
                ),
            )
            if getattr(response, "parsed", None) is not None:
                parsed = response.parsed
                if isinstance(parsed, response_model):
                    return parsed
                return response_model.model_validate(parsed)
            response_text = getattr(response, "text", None)
            if not response_text:
                raise AgentError("Gemini returned an empty response.")
            return response_model.model_validate_json(response_text)
        except AgentError:
            raise
        except Exception as exc:
            raise AgentError(f"Gemini request failed: {exc}") from exc


class InputParsingAgent(GeminiResponseAgent):
    """Validates prompt, extracts intent summary, recipient, tone, constraints."""

    def run(
        self,
        *,
        user_message: str,
        context: UserEmailContext,
        temperature: float,
    ) -> ParsedInput:
        payload = {"user_message": user_message, "provided_context": context.model_dump()}
        messages = [
            {"role": "system", "content": prompts.INPUT_PARSING_SYSTEM_PROMPT},
            {"role": "user", "content": json.dumps(payload, indent=2)},
        ]
        return self._parse(
            messages=messages,
            response_model=ParsedInput,
            temperature=temperature,
        )


class IntentDetectionAgent(GeminiResponseAgent):
    """Classifies intent: outreach, follow-up, apology, info, etc."""

    def run(
        self,
        *,
        user_message: str,
        parsed: ParsedInput,
        context: UserEmailContext,
        temperature: float,
    ) -> IntentClassification:
        payload = {
            "user_message": user_message,
            "parsed_input": parsed.model_dump(),
            "provided_context": context.model_dump(),
        }
        messages = [
            {"role": "system", "content": prompts.INTENT_DETECTION_SYSTEM_PROMPT},
            {"role": "user", "content": json.dumps(payload, indent=2)},
        ]
        return self._parse(
            messages=messages,
            response_model=IntentClassification,
            temperature=temperature,
        )


class ToneStylistAgent(GeminiResponseAgent):
    """Adjusts tone using tokenized prompts (tone_tokens + composed directive)."""

    def run(
        self,
        *,
        parsed: ParsedInput,
        intent: IntentClassification,
        context: UserEmailContext,
        temperature: float,
    ) -> ToneStyleSpec:
        payload = {
            "parsed_input": parsed.model_dump(),
            "intent_classification": intent.model_dump(),
            "provided_context": context.model_dump(),
        }
        messages = [
            {"role": "system", "content": prompts.TONE_STYLIST_SYSTEM_PROMPT},
            {"role": "user", "content": json.dumps(payload, indent=2)},
        ]
        return self._parse(
            messages=messages,
            response_model=ToneStyleSpec,
            temperature=temperature,
        )


class DraftWriterAgent(GeminiResponseAgent):
    """Generates main body with structure and clarity."""

    def run(
        self,
        *,
        parsed: ParsedInput,
        intent: IntentClassification,
        tone: ToneStyleSpec,
        context_pack: ContextPack,
        context: UserEmailContext,
        revision_fixes: Optional[List[str]] = None,
        temperature: float,
    ) -> EmailDraft:
        payload = {
            "parsed_input": parsed.model_dump(),
            "intent_classification": intent.model_dump(),
            "tone_style_spec": tone.model_dump(),
            "context_pack": context_pack.model_dump(),
            "provided_context": context.model_dump(),
            "revision_fixes": revision_fixes or [],
        }
        messages = [
            {"role": "system", "content": prompts.DRAFT_WRITER_SYSTEM_PROMPT},
            {
                "role": "user",
                "content": (
                    "Write the email draft.\n\n"
                    f"{json.dumps(payload, indent=2)}\n\n"
                    "If revision_fixes is non-empty, incorporate them."
                ),
            },
        ]
        return self._parse(
            messages=messages,
            response_model=EmailDraft,
            temperature=temperature,
        )


class PersonalizationAgent(GeminiResponseAgent):
    """Injects user profile data and prior messages."""

    def run(
        self,
        *,
        draft: EmailDraft,
        parsed: ParsedInput,
        intent: IntentClassification,
        tone: ToneStyleSpec,
        context_pack: ContextPack,
        context: UserEmailContext,
        prior_messages: Optional[List[str]] = None,
        refinement_fixes: Optional[List[str]] = None,
        profile_memory: Optional[dict] = None,
        temperature: float,
    ) -> PersonalizedEmail:
        payload = {
            "draft": draft.model_dump(),
            "parsed_input": parsed.model_dump(),
            "intent_classification": intent.model_dump(),
            "tone_style_spec": tone.model_dump(),
            "context_pack": context_pack.model_dump(),
            "provided_context": context.model_dump(),
            "prior_messages": prior_messages or [],
            "refinement_fixes": refinement_fixes or [],
            "profile_memory": profile_memory or {},
        }
        messages = [
            {"role": "system", "content": prompts.PERSONALIZATION_SYSTEM_PROMPT},
            {"role": "user", "content": json.dumps(payload, indent=2)},
        ]
        return self._parse(
            messages=messages,
            response_model=PersonalizedEmail,
            temperature=temperature,
        )


class ReviewValidatorAgent(GeminiResponseAgent):
    """Grammar, tone alignment, contextual coherence."""

    def run(
        self,
        *,
        parsed: ParsedInput,
        intent: IntentClassification,
        tone: ToneStyleSpec,
        context_pack: ContextPack,
        polished: PersonalizedEmail,
        temperature: float,
    ) -> ReviewResult:
        payload = {
            "parsed_input": parsed.model_dump(),
            "intent_classification": intent.model_dump(),
            "tone_style_spec": tone.model_dump(),
            "context_pack": context_pack.model_dump(),
            "email": polished.model_dump(),
        }
        messages = [
            {"role": "system", "content": prompts.REVIEW_VALIDATOR_SYSTEM_PROMPT},
            {"role": "user", "content": json.dumps(payload, indent=2)},
        ]
        return self._parse(
            messages=messages,
            response_model=ReviewResult,
            temperature=temperature,
        )


class RoutingMemoryAgent(GeminiResponseAgent):
    """Fallback routing decision + memory note (orchestrator also logs structurally)."""

    def run(
        self,
        *,
        summary: dict,
        temperature: float,
    ) -> RoutingDecision:
        messages = [
            {"role": "system", "content": prompts.ROUTING_MEMORY_SYSTEM_PROMPT},
            {"role": "user", "content": json.dumps(summary, indent=2)},
        ]
        return self._parse(
            messages=messages,
            response_model=RoutingDecision,
            temperature=temperature,
        )
